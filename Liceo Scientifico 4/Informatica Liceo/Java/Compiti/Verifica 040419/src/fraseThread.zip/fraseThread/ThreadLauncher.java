package fraseThread;

public class ThreadLauncher {

	public static void main(String[] args) {
		FraseThread fT = new FraseThread("Ciao, come stai?");
		fT.start();

	}

}
