package party;

public class Friend {
	
	private int friendshipRating;

	public Friend(int friendshipRating) {
		super();
		this.friendshipRating = friendshipRating;
	}

	public int getFriendshipRating() {
		return friendshipRating;
	}
	
	

}
