	package Quantum;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class QuantunPCManager {
	
	private static final long VAL = 100003;
	
	private ArrayList<QuantumPC> pcs;
	
	private String fIn, fOut;
	
	public void initPC() {
		BufferedReader buffR = null;
		try {
			buffR = new BufferedReader(new FileReader(fIn));
			
			int testCases = Integer.parseInt(buffR.readLine());
			for(int nT = 0; nT < testCases; nT++) {
				buffR.readLine();
				String qCoord[] = buffR.readLine().split(" ");
				int xQ = Integer.parseInt(qCoord[0]);
				int yQ = Integer.parseInt(qCoord[1]);
				
				Qubit q = new Qubit(xQ, yQ);
				
				int nPort = Integer.parseInt(buffR.readLine());
				ArrayList<Portal> portals = new ArrayList<Portal>();
				for(int nPo = 0; nPo < nPort; nPo++) {
					String[] pCoo = buffR.readLine().split(" ");
					portals.add(new Portal(Integer.parseInt(pCoo[0]), Integer.parseInt(pCoo[1]), Integer.parseInt(pCoo[2]), Integer.parseInt(pCoo[3])));
				}
				pcs.add(new QuantumPC(portals, q));
				
				
			}
			
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(buffR != null) {
				try {
					
					buffR.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
	
	public void run() {
		for(QuantumPC p: pcs) {
			p.runPC();
		}
	}
	
	
	public QuantunPCManager(String fIn, String fOut) {
		super();
		this.pcs = new ArrayList<QuantumPC>();
		this.fIn = fIn;
		this.fOut = fOut;
	}

	public void saveOutput() {
		FileWriter fW = null;
		try {
			fW = new FileWriter(fOut);
			
			int n = 1;
			for(QuantumPC p: pcs) {
				fW.write("Case #"+n+": "+Math.floorMod(p.getMovements(), VAL));
				fW.write("\r\n");
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(fW != null) {
				try {
					fW.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally {
					try {
						fW.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		QuantunPCManager pc = new QuantunPCManager("C:\\Users\\franc\\OneDrive\\Desktop\\QuantumPC files\\input-teleportation-cfdc.txt", "C:\\Users\\franc\\OneDrive\\Desktop\\QuantumPC files\\output-teleportation-cfdc.txt");
		pc.initPC();
		pc.run();
		pc.saveOutput();
		

	}

}
